﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imc2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btmSair_Click(object sender, EventArgs e)
        {

        }

        private void btmCalcular_Click(object sender, EventArgs e)
        {
            double vlrAltura, vlrPeso;
            if ((!double.TryParse(txtAltura.Text, out vlrAltura))
                || (!double.TryParse(txtPeso.Text, out vlrPeso)))
            {
                MessageBox.Show("Valores invalidos ");
                txtAltura.Focus();
            }
            else if (vlrAltura <= 0 || vlrPeso <= 0)
            {
                MessageBox.Show("valores invalidos");
                txtAltura.Focus();
            }
            else
            {
                double vlrImc;
                vlrImc = vlrPeso / Math.Pow(vlrAltura, 2);
                vlrImc = Math.Round(vlrImc, 1);
                if (vlrImc <= 18.5)
                    MessageBox.Show("magreza");
                else if (vlrImc <= 24.9)
                    MessageBox.Show("normal");
                else if (vlrImc <= 29.9)
                    MessageBox.Show("sobre peso");
                else if (vlrImc <= 39.9)
                    MessageBox.Show("obesidade");
                else
                }
            MessageBox.Show("obesidade grave");
        }

    }

    private void txtAltura_Validated(object sender, EventArgs e)
    {
        double VlrAltura;
        if (!double.TryParse(txtAltura.Text, out VlrAltura))
            MessageBox.Show("Altura inválida");
        else
            if (VlrAltura <= 0)
            MessageBox.Show("Altura deve ser maior que zero");

    }

    private void txtPeso_Validated(object sender, EventArgs e)
    {
        double vlrPeso;
        if (!double.TryParse(txtPeso.Text, out vlrPeso))
            MessageBox.Show("Peso invalido");
        else
            if (vlrPeso <= 0)
            MessageBox.Show("Peso deve ser maior que zero");

    }

}
